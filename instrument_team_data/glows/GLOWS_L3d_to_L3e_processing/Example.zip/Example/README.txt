Execute run_example_L3d_to_L3e.sh to generate probSur.Imap.*.dat text files with L3e survival probabilities

Then execute run_validation_for_L3e.sh to validate your newly generated probSur.Imap.*.dat files by comparison
with files provided by Marzena Kubiak in the directory L3e_output_from_M_Kubiak_for_validation
Only lines containing "Date of calculation:" are expected to be different if the validation is successful
